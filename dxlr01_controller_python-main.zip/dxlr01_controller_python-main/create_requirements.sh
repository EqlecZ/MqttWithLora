###
 # @Author: Y.Y. Daniel 626986815@qq.com
 # @Date: 2024-08-10 18:25:14
 # @LastEditors: Y.Y. Daniel 626986815@qq.com
 # @LastEditTime: 2024-08-10 18:25:21
 # @FilePath: /dxlr01_controller_python/create_requirements.sh
 # @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
### 
pipreqs . --encoding=utf8 --force